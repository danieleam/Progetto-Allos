package AllosProject.PrenotazioniAeree.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import AllosProject.PrenotazioniAeree.model.Aereoporto;
import AllosProject.PrenotazioniAeree.model.Compagnia;
import AllosProject.PrenotazioniAeree.model.Prenotazione;
import AllosProject.PrenotazioniAeree.model.Utente;
import AllosProject.PrenotazioniAeree.model.Volo;
import AllosProject.PrenotazioniAeree.repository.IRepoAereoporto;
import AllosProject.PrenotazioniAeree.repository.IRepoCompagnia;
import AllosProject.PrenotazioniAeree.repository.IRepoPrenotazione;
import AllosProject.PrenotazioniAeree.repository.IRepoUtente;
import AllosProject.PrenotazioniAeree.repository.IRepoVolo;

@Controller
public class AvvioAdmin {

	@Autowired
	IRepoVolo rv;

	@Autowired
	IRepoAereoporto ra;

	@Autowired
	IRepoCompagnia rc;

	@Autowired
	IRepoUtente ru;
	
	@Autowired
	IRepoPrenotazione rp;

	//-----INSERIMENTO/MODIFICA VOLO-----
	@PostMapping(value = "insertUpdateVolo")
	public String inserisciModificaVolo(Volo volo) {
		rv.save(volo);
		return "redirect:/viewVoliAdmin";
	}

	//-----ELIMINA VOLO-----
	@GetMapping(value = "deleteVolo")
	public String deleteMarca(@RequestParam int id) {
		rv.deleteById(id);
		return "redirect:/viewVoliAdmin";
	}

	//-----INSERIMENTO/MODIFICA AEREOPORTO-----
	@PostMapping(value = "insertUpdateAereoporto")
	public String inserisciModificaAereoporto(Aereoporto aereoporto) {
		ra.save(aereoporto);
		return "redirect:/viewCompagnieAereoportiAdmin";
	}

	//-----ELIMINA AEREOPORTO-----
	@GetMapping(value = "deleteAereoporto")
	public String deleteAereoporto(@RequestParam int id) {
		ra.deleteById(id);
		return "redirect:/viewCompagnieAereoportiAdmin";
	}

	//-----INSERIMENTO/MODIFICA COMPAGNIA-----
	@PostMapping(value = "insertUpdateCompagnia")
	public String inserisciModificaCompagnia(Compagnia compagnia) {
		rc.save(compagnia);
		return "redirect:/viewCompagnieAereoportiAdmin";
	}

	//-----ELIMINA COMPAGNIA-----
	@GetMapping(value = "deleteCompagnia")
	public String deleteCompagnia(@RequestParam int id) {
		rc.deleteById(id);
		return "redirect:/viewCompagnieAereoportiAdmin";
	}

	//-----ELIMINA UTENTE ADMIN-----
	@GetMapping(value = "deleteUtenteAdmin")
	public String deleteUtenteAdmin(@RequestParam int id) {
		ru.deleteById(id);
		return "redirect:/viewUtentiAdmin";
	}
	
	//-----LOGIN ADMIN-----//
	@GetMapping(value = "/login")
	public String login() {
		return "Admin/login";
	}

	//-----MOSTRA TUTTI I VOLI CON IMPAGINAZIONE-----
	@GetMapping(value = "viewVoliAdmin")
	public String viewVoliAdmin(HttpServletRequest request, @RequestParam(required = false) String keyword) {
		ArrayList<Volo> listaFiltrata = new ArrayList<>();
		List<Volo> listaVoli;
		if (keyword == null || keyword.equals(""))
			listaVoli = rv.findAll();
		else if (rv.findByKeyword(keyword).size() == 0)
			listaVoli = rv.findAll();
		// messaggio da inviare
		else
			listaVoli = rv.findByKeyword(keyword);

		int pagina = 1;

		if (request.getParameter("pagina") != null) {
			pagina = Integer.parseInt(request.getParameter("pagina"));
		}

		int nPagine = 0;
		int totElementi = listaVoli.size();
		int nVisualizzati = 7;
		int offset = 0;
		int limit = 0;

		if (totElementi % nVisualizzati != 0) // controlliamo se il rapporto ha resto
			nPagine = (totElementi / nVisualizzati) + 1; // incremento per eccesso per non perdere una pagina
		else
			nPagine = (totElementi / nVisualizzati);
		if (pagina == 0) { // se pagina–- porta a pagina=0, la variabile pagina viene riportata a 1
			pagina = 1;
		} else if (pagina > nPagine) { // controllo se pagina++ supera il limite delle pagine
			pagina = nPagine;
		}
		// offset e limit variano in funzione della variabile "pagina"
		offset = (pagina - 1) * nVisualizzati;
		limit = offset + nVisualizzati;
		for (int i = offset; i < limit && i < listaVoli.size(); i++) {
			listaFiltrata.add(listaVoli.get(i));
		}
		request.setAttribute("keyword", keyword);
		request.setAttribute("voli", listaFiltrata);
		request.setAttribute("nPagine", nPagine);
		request.setAttribute("pagina", pagina);
		request.setAttribute("aereoporti", ra.findAll());
		request.setAttribute("compagnie", rc.findAll());
		return "Admin/voli";
	}

	//-----MOSTRA TUTTI GLI AEREOPORTI CON IMPAGINAZIONE-----
	@GetMapping(value = "viewCompagnieAereoportiAdmin")
	public String viewCompagnieAereoportiAdmin(HttpServletRequest request,
			@RequestParam(required = false) String keyword) {
		// IMPAGINAZIONE AEREOPORTI
		List<Aereoporto> listaFiltrataAereoporti = new ArrayList<>();
		List<Aereoporto> listaAereoporti = null;
		List<Compagnia> listaCompagnie = null;

		if (keyword == null || keyword.equals("")) {
			listaAereoporti = ra.findAll(); // Sort.by(Sort.Direction.ASC, "nome") per ordinare
			listaCompagnie = rc.findAll();
		} else {
			if (ra.findByKeyword(keyword).size() == 0) {
				listaAereoporti = ra.findAll();
				request.setAttribute("trovatiAereoporti", "falso");
			} else
				listaAereoporti = ra.findByKeyword(keyword);
			if (rc.findByKeyword(keyword).size() == 0) {
				listaCompagnie = rc.findAll();
				request.setAttribute("trovatiCompagnia", "falso");
			} else
				listaCompagnie = rc.findByKeyword(keyword);
		}

		int pagina = 1;

		if (request.getParameter("paginaAereoporti") != null) {
			pagina = Integer.parseInt(request.getParameter("paginaAereoporti"));
		}

		int nPagine = 0;
		int totElementi = listaAereoporti.size();
		int nVisualizzati = 7;
		int offset = 0;
		int limit = 0;

		if (totElementi % nVisualizzati != 0) // controlliamo se il rapporto ha resto
			nPagine = (totElementi / nVisualizzati) + 1; // incremento per eccesso per non perdere una pagina
		else
			nPagine = (totElementi / nVisualizzati);
		if (pagina == 0) { // se pagina–- porta a pagina=0, la variabile pagina viene riportata a 1
			pagina = 1;
		} else if (pagina > nPagine) { // controllo se pagina++ supera il limite delle pagine
			pagina = nPagine;
		}
		// offset e limit variano in funzione della variabile "pagina"
		offset = (pagina - 1) * nVisualizzati;
		limit = offset + nVisualizzati;
		for (int i = offset; i < limit && i < listaAereoporti.size(); i++) {
			listaFiltrataAereoporti.add(listaAereoporti.get(i)); // prendo solo i valori delimitati da offset e limit
		}
		request.setAttribute("aereoporti", listaFiltrataAereoporti);
		request.setAttribute("nPagineAereoporti", nPagine);
		request.setAttribute("paginaAereoporti", pagina);

		// IMPAGINAZIONE COMPAGNIE
		ArrayList<Compagnia> listaFiltrataCompagnie = new ArrayList<>();

		int pagina2 = 1;

		if (request.getParameter("paginaCompagnie") != null) {
			pagina2 = Integer.parseInt(request.getParameter("paginaCompagnie"));
		}

		int nPagine2 = 0;
		int totElementi2 = listaCompagnie.size();
		int nVisualizzati2 = 7;
		int offset2 = 0;
		int limit2 = 0;

		if (totElementi2 % nVisualizzati2 != 0) // controlliamo se il rapporto ha resto
			nPagine2 = (totElementi2 / nVisualizzati2) + 1; // incremento per eccesso per non perdere una pagina
		else
			nPagine2 = (totElementi2 / nVisualizzati2);
		if (pagina2 == 0) { // se pagina–- porta a pagina=0, la variabile pagina viene riportata a 1
			pagina2 = 1;
		} else if (pagina2 > nPagine2) { // controllo se pagina++ supera il limite delle pagine
			pagina2 = nPagine2;
		}
		// offset e limit variano in funzione della variabile "pagina"
		offset2 = (pagina2 - 1) * nVisualizzati2;
		limit2 = offset2 + nVisualizzati2;
		for (int i = offset2; i < limit2 && i < listaCompagnie.size(); i++) {
			listaFiltrataCompagnie.add(listaCompagnie.get(i)); // prendo solo i valori delimitati da offset e limit
		}
		request.setAttribute("compagnie", listaFiltrataCompagnie);
		request.setAttribute("nPagineCompagnie", nPagine2);
		request.setAttribute("paginaCompagnie", pagina2);

		request.setAttribute("keyword", keyword); // un solo request per entrambi

		return "Admin/AereoportiCompagnie";
	}

	//-----MOSTRA TUTTI GLI UTENTI CON IMPAGINAZIONE-----
	@GetMapping(value = "viewUtentiAdmin")
	public String viewUtentiAdmin(HttpServletRequest request, @RequestParam(required = false) String keyword) {
		ArrayList<Utente> listaFiltrata = new ArrayList<>();
		List<Utente> listaUtenti;
		if (keyword == null || keyword.equals(""))
			listaUtenti = ru.findAll();
		else if (ru.findByKeyword(keyword).size() == 0)
			listaUtenti = ru.findAll();
		else
			listaUtenti = ru.findByKeyword(keyword);

		int pagina = 1;

		if (request.getParameter("pagina") != null) {
			pagina = Integer.parseInt(request.getParameter("pagina"));
		}

		int nPagine = 0;
		int totElementi = listaUtenti.size();
		int nVisualizzati = 7;
		int offset = 0;
		int limit = 0;

		if (totElementi % nVisualizzati != 0) // controlliamo se il rapporto ha resto
			nPagine = (totElementi / nVisualizzati) + 1; // incremento per eccesso per non perdere una pagina
		else
			nPagine = (totElementi / nVisualizzati);
		if (pagina == 0) { // se pagina–- porta a pagina=0, la variabile pagina viene riportata a 1
			pagina = 1;
		} else if (pagina > nPagine) { // controllo se pagina++ supera il limite delle pagine
			pagina = nPagine;
		}
		// offset e limit variano in funzione della variabile "pagina"
		offset = (pagina - 1) * nVisualizzati;
		limit = offset + nVisualizzati;
		for (int i = offset; i < limit && i < listaUtenti.size(); i++) {
			listaFiltrata.add(listaUtenti.get(i));
		}
		request.setAttribute("keyword", keyword);
		request.setAttribute("utenti", listaFiltrata);
		request.setAttribute("nPagine", nPagine);
		request.setAttribute("pagina", pagina);
		return "Admin/utenti";
	}

	//-----MOSTRA TUTTE LE PRENOTAZIONI CON IMPAGINAZIONE-----
	@GetMapping(value = "viewPrenotazioniAdmin")
	public String viewPrenotazioniAdmin(HttpServletRequest request) {
		ArrayList<Prenotazione> listaFiltrata = new ArrayList<>();
		List<Prenotazione> listaPrenotazioni = rp.findAll();
		int pagina = 1;

		if (request.getParameter("pagina") != null) {
			pagina = Integer.parseInt(request.getParameter("pagina"));
		}

		int nPagine = 0;
		int totElementi = listaPrenotazioni.size();
		int nVisualizzati = 7;
		int offset = 0;
		int limit = 0;

		if (totElementi % nVisualizzati != 0) // controlliamo se il rapporto ha resto
			nPagine = (totElementi / nVisualizzati) + 1; // incremento per eccesso per non perdere una pagina
		else
			nPagine = (totElementi / nVisualizzati);
		if (pagina == 0) { // se pagina–- porta a pagina=0, la variabile pagina viene riportata a 1
			pagina = 1;
		} else if (pagina > nPagine) { // controllo se pagina++ supera il limite delle pagine
			pagina = nPagine;
		}
		// offset e limit variano in funzione della variabile "pagina"
		offset = (pagina - 1) * nVisualizzati;
		limit = offset + nVisualizzati;
		for (int i = offset; i < limit && i < listaPrenotazioni.size(); i++) {
			listaFiltrata.add(listaPrenotazioni.get(i));
		}
		request.setAttribute("prenotazioni", listaFiltrata);
		request.setAttribute("nPagine", nPagine);
		request.setAttribute("pagina", pagina);
		return "Admin/prenotazioni";
	}

}
