package AllosProject.PrenotazioniAeree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import AllosProject.PrenotazioniAeree.model.Aereoporto;

public interface IRepoAereoporto extends JpaRepository<Aereoporto, Integer> {
	
	public Aereoporto findById(int id);
	
	@Query(value="Select * from aereoporti where nome like %?1%", nativeQuery=true)
	public List<Aereoporto> findByKeyword(String keyword);

}
