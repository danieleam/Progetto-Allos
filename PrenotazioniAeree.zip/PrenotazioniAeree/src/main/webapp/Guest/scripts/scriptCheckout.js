// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
	'use strict'

	var forms;
	// Fetch all the forms we want to apply custom Bootstrap validation styles to
	if (document.getElementById('cartaDiCredito').checked) {
		forms = document.querySelectorAll('.needs-validation')
	}
	else
		forms = document.querySelectorAll('.validationDati')

	// Loop over them and prevent submission
	Array.from(forms).forEach(form => {
		form.addEventListener('submit', event => {
			if (!form.checkValidity()) {
				event.preventDefault()
				event.stopPropagation()
			}

			form.classList.add('was-validated')
		}, false)
	})
})()

document.body.addEventListener('change', function(e) {
	let target = e.target;
	switch (target.id) {
		case 'cartaDiCredito':
			$('#datiCarta').show();
			break;
		case 'googlePay':
			$('#datiCarta').hide();
			break;
		case 'applePay':
			$('#datiCarta').hide();
			break;
		case 'paypal':
			$('#datiCarta').hide();
			break;
	}
});
