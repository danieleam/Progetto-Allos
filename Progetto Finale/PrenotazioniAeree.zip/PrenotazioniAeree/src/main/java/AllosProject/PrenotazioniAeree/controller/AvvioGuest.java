package AllosProject.PrenotazioniAeree.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import AllosProject.PrenotazioniAeree.model.Prenotazione;
import AllosProject.PrenotazioniAeree.model.Utente;
import AllosProject.PrenotazioniAeree.model.Volo;
import AllosProject.PrenotazioniAeree.repository.IRepoAereoporto;
import AllosProject.PrenotazioniAeree.repository.IRepoCompagnia;
import AllosProject.PrenotazioniAeree.repository.IRepoPrenotazione;
import AllosProject.PrenotazioniAeree.repository.IRepoUtente;
import AllosProject.PrenotazioniAeree.repository.IRepoVolo;

@Controller
public class AvvioGuest {

	@Autowired
	IRepoVolo rv;

	@Autowired
	IRepoUtente ru;

	@Autowired
	IRepoAereoporto ra;

	@Autowired
	IRepoCompagnia rc;

	@Autowired
	IRepoPrenotazione rp;

	HttpSession sessione;

	// -----HOME-----//
	@GetMapping(value = "")
	public String home(HttpServletRequest request) {
		List<Volo> voliQuery = rv.findVoliScontati();
		List<Volo> voliHome = new ArrayList<Volo>();
		int MAXELEM;
		int[] indiceVoli = new int[3];// max di voli da visualizzare nella home
		boolean flag;
		if (voliQuery.size() >= 3)// se ho 3 o più voli
			MAXELEM = 3;
		else// se ne ho 2 o meno
			MAXELEM = voliQuery.size();
		do {
			flag = true;// setto il flag a true
			for (int i = 0; i <= MAXELEM - 1; i++) {// genera numeri random basati sui voli all'interno della lista
				indiceVoli[i] = new Random().nextInt(voliQuery.size());
			}
			if (voliQuery.size() >= 2) {// controllo se i numeri presi non sono uguali
				if (indiceVoli[0] == indiceVoli[1])
					flag = false;
				if (voliQuery.size() >= 3) {
					if (indiceVoli[1] == indiceVoli[2])
						flag = false;
					else if (indiceVoli[2] == indiceVoli[0])
						flag = false;
				}
			}
		} while (!flag);
		for (int i = 0; i <= MAXELEM - 1; i++) {// genera numeri random basati sui prodotti all'interno della lista
			voliHome.add(voliQuery.get(indiceVoli[i]));
		}
		request.setAttribute("logo", "Guest/img/airplane.png");
		request.setAttribute("banner1", "Guest/img/tropical.jpg");
		request.setAttribute("banner2", "Guest/img/banner1.png");
		request.setAttribute("triangolo", "Guest/img/triangolo.png");
		request.setAttribute("lowcost", "Guest/img/lowcost.jpg");
		request.setAttribute("voli", voliHome);
		request.setAttribute("aereoporti", ra.findAll(Sort.by(Sort.Direction.ASC, "nome")));
		return "Guest/home";
	}
	
	//-----RICERCA VOLI ANDATA-----//
	@GetMapping(value = "ricercaVoliAndata")
	public String ricercaVoliAndata(HttpServletRequest request, HttpServletResponse response,
			@RequestParam String cittaPartenza, @RequestParam String cittaArrivo, @RequestParam Date Andata,
			@RequestParam(required = false) Date Ritorno, @RequestParam int totaleAdulti,
			@RequestParam int totaleBambini, @RequestParam String radioButton) { // required = false sto dicendo che il
																					// parametro Ritorno non dev'essere
																					// obbligatorio
		List<Volo> listaVoli = rv.searchVoliAndata(cittaPartenza, cittaArrivo, Andata, totaleAdulti + totaleBambini);
		for (int i = 0; i < listaVoli.size(); i++) {
			for (int j = 0; j < listaVoli.size() - 1; j++) {
				if (listaVoli.get(j).getData().after(listaVoli.get(j + 1).getData())) {
					Volo tempVolo;
					tempVolo = listaVoli.get(j);
					listaVoli.set(j, listaVoli.get(j + 1));
					listaVoli.set(j + 1, tempVolo);
				}
			}
		}
		request.setAttribute("PasseggeriAdulti", totaleAdulti);
		request.setAttribute("PasseggeriBambini", totaleBambini);
		request.setAttribute("triangolo", "Guest/img/triangolo.png");
		request.setAttribute("logo", "Guest/img/airplane.png");
		request.setAttribute("voli", listaVoli); // ANDATA
		request.setAttribute("dataAndata", Andata);
		request.setAttribute("aereoporti", ra.findAll(Sort.by(Sort.Direction.ASC, "nome")));
		if (radioButton.equals("AndataRitorno")) {
			request.setAttribute("AndataRitorno", "vero");
			request.setAttribute("cittaPartenza", cittaPartenza);
			request.setAttribute("cittaArrivo", cittaArrivo);
			request.setAttribute("dataRitorno", Ritorno);
		}
		return "Guest/voli";
	}
	
	//----RICERCA VOLI RITORNO-----//
	@GetMapping(value = "ricercaVoliRitorno")
	public String ricercaVoliRitorno(HttpServletRequest request, @RequestParam String cittaPartenza,
			@RequestParam String cittaArrivo, @RequestParam Date Andata, @RequestParam Date Ritorno,
			@RequestParam int totaleAdulti, @RequestParam int totaleBambini, @RequestParam int idAndata,
			@RequestParam Time ora) {
		request.setAttribute("PasseggeriAdulti", totaleAdulti);
		request.setAttribute("PasseggeriBambini", totaleBambini);
		request.setAttribute("id_voloAndata", idAndata);
		request.setAttribute("prenotazioneAR", "vero");
		request.setAttribute("triangolo", "Guest/img/triangolo.png");
		request.setAttribute("logo", "Guest/img/airplane.png");
		List<Volo> listaVoli = rv.searchVoliRitorno(cittaArrivo, cittaPartenza, Ritorno, totaleAdulti + totaleBambini,
				Andata, ora);
		for (int i = 0; i < listaVoli.size(); i++) {
			for (int j = 0; j < listaVoli.size() - 1; j++) {
				if (listaVoli.get(j).getData().after(listaVoli.get(j + 1).getData())) {
					Volo tempVolo;
					tempVolo = listaVoli.get(j);
					listaVoli.set(j, listaVoli.get(j + 1));
					listaVoli.set(j + 1, tempVolo);
				}
			}
		}
		request.setAttribute("voli", listaVoli); // RITORNO
		request.setAttribute("aereoporti", ra.findAll(Sort.by(Sort.Direction.ASC, "nome")));
		return "Guest/voli";
	}

	// -----REGISTRAZIONE UTENTE-----//
	@PostMapping(value = "registrazioneModificaUtente")
	public String registrazioneModifica(HttpServletRequest request, Utente utente) {
		ru.save(utente);
		return request.getParameter("url");
	}
	
	//-----ELIMINA UTENTE-----
		@GetMapping(value = "deleteUtente")
		public String deleteUtente(@RequestParam int id) {
			ru.deleteById(id);
			sessione.invalidate();
			return "redirect:/";
		}
	
	// ----LOGIN UTENTE-----//
	@PostMapping(value = "loginUtente")
	public String loginUtente(HttpServletRequest request, HttpServletResponse respone, @RequestParam String email,
			@RequestParam String password) throws IOException {
		sessione = request.getSession();
		for (int i = 0; i < ru.findAll().size(); i++) {
			if ((ru.findAll().get(i).getEmail().equals(email))
					&& (ru.findAll().get(i).getPassword().equals(password))) {
				sessione.setAttribute("id", ru.findAll().get(i).getId_utente());
				sessione.setAttribute("nome", ru.findAll().get(i).getNome());
				sessione.setAttribute("login", "vero");
			} else if ((email.equals("user@admin.it")) && (password.equals("password"))) {
				sessione.setAttribute("email", email);
				sessione.setAttribute("password", password);
				return "redirect:/Admin"; // mi reindirizza al login dell'admin
			}
		}
		return "redirect:/";
	}

	// ----VISUALIZZA DATI SINGOLO UTENTE-----//
	@GetMapping(value = "viewUtente")
	public String viewUtente(HttpServletRequest request, @RequestParam int id) {
		request.setAttribute("logo", "Guest/img/airplane.png");
		request.setAttribute("utente", ru.findById(id));
		request.setAttribute("prenotazioni", rp.findByUtente(id));
		return "Guest/profilo";
	}

	// ----LOGOUT UTENTE-----
	@GetMapping(value = "logoutUtente")
	public String logoutUtente(HttpServletRequest request, @RequestParam int num) {
		sessione = request.getSession();
		if (num == 1) {
			sessione.invalidate();
		}
		return "redirect:/";
	}

	// ----PRENOTAZIONE BIGLIETTI-----//
	@GetMapping(value = "prenotazioni")
	public String prenotazione(HttpServletRequest request, @RequestParam int idAndata,
			@RequestParam(required = false, defaultValue = "0") int idRitorno, @RequestParam int totaleAdulti,
			@RequestParam int totaleBambini) {
		request.setAttribute("PasseggeriAdulti", totaleAdulti);
		request.setAttribute("PasseggeriBambini", totaleBambini);
		request.setAttribute("logo", "Guest/img/airplane.png");
		request.setAttribute("logo", "Guest/img/airplane.png");
		request.setAttribute("voloAndata", rv.findById(idAndata));
		if (idRitorno != 0) {
			request.setAttribute("voloRitorno", rv.findById(idRitorno));
			request.setAttribute("prenotaRitorno", "vero");
		}
		return "Guest/prenotazioneBiglietti";
	}

	// -----CHECKOUT-----//
	@PostMapping(value = "checkout")
	public String checkout(HttpServletRequest request, @RequestParam int idAndata,
			@RequestParam(required = false, defaultValue = "0") int idRitorno, @RequestParam int totaleAdulti,
			@RequestParam int totaleBambini) {
		request.setAttribute("voloAndata", rv.findById(idAndata));
		request.setAttribute("PasseggeriAdulti", totaleAdulti);
		request.setAttribute("PasseggeriBambini", totaleBambini);
		if (idRitorno != 0) {
			request.setAttribute("voloRitorno", rv.findById(idRitorno));
			request.setAttribute("prenotaRitorno", "vero");
		}

		List<Prenotazione> listaPrenotazione = new ArrayList<Prenotazione>();
		// java.util.Date date = new java.util.Date();
		java.sql.Date sqlDate = new Date(new java.util.Date().getTime());

		for (int i = 1; i < totaleAdulti + 1; i++) {
			Prenotazione p = new Prenotazione();
			p.setNome(request.getParameter("nome" + i));
			p.setCognome(request.getParameter("cognome" + i));
			p.setEta(Integer.parseInt(request.getParameter("eta" + i)));
			p.setData(sqlDate);
			p.setOra(java.sql.Time.valueOf(LocalTime.now())); // localtime mi restituisce l'ora corrente
			p.setUtente(ru.findById((int) sessione.getAttribute("id")));
			p.setVolo(rv.findById(idAndata));
			listaPrenotazione.add(p);
		}

		for (int i = 1; i < totaleBambini + 1; i++) {
			Prenotazione p = new Prenotazione();
			p.setNome(request.getParameter("nomeBambino" + i));
			p.setCognome(request.getParameter("cognomeBambino" + i));
			p.setEta(Integer.parseInt(request.getParameter("etaBambino" + i)));
			p.setData(sqlDate);
			p.setOra(java.sql.Time.valueOf(LocalTime.now())); // localtime mi restituisce l'ora corrente
			p.setUtente(ru.findById((int) sessione.getAttribute("id")));
			p.setVolo(rv.findById(idAndata));
			listaPrenotazione.add(p);
		}

		if (idRitorno != 0) {
			for (int i = 1; i < totaleAdulti + 1; i++) {
				Prenotazione p = new Prenotazione();
				p.setNome(request.getParameter("nome" + i));
				p.setCognome(request.getParameter("cognome" + i));
				p.setEta(Integer.parseInt(request.getParameter("eta" + i)));
				p.setData(sqlDate);
				p.setOra(java.sql.Time.valueOf(LocalTime.now())); // localtime mi restituisce l'ora corrente
				p.setUtente(ru.findById((int) sessione.getAttribute("id")));
				p.setVolo(rv.findById(idRitorno));
				listaPrenotazione.add(p);
			}

			for (int i = 1; i < totaleBambini + 1; i++) {
				Prenotazione p = new Prenotazione();
				p.setNome(request.getParameter("nomeBambino" + i));
				p.setCognome(request.getParameter("cognomeBambino" + i));
				p.setEta(Integer.parseInt(request.getParameter("etaBambino" + i)));
				p.setData(sqlDate);
				p.setOra(java.sql.Time.valueOf(LocalTime.now())); // localtime mi restituisce l'ora corrente
				p.setUtente(ru.findById((int) sessione.getAttribute("id")));
				p.setVolo(rv.findById(idRitorno));
				listaPrenotazione.add(p);
			}
		}

		sessione.setAttribute("prenotazione", listaPrenotazione);

		return "Guest/checkout";
	}
	
	//-----INSERT PRENOTAZIONE-----//
	@GetMapping(value = "insertPrenotazione")
	public String insertPrenotazione(@RequestParam int idAndata,
			@RequestParam(required = false, defaultValue = "0") int idRitorno) {

		ArrayList<Prenotazione> listaPrenotazioni = (ArrayList<Prenotazione>) sessione.getAttribute("prenotazione");
		if (rv.findById(idAndata).getNumPasseggeri() >= listaPrenotazioni.size()) {
			for (Prenotazione p : listaPrenotazioni) {
				rp.save(p);
			}
			Volo volo = rv.findById(idAndata);
			volo.setNumPasseggeri(volo.getNumPasseggeri() - listaPrenotazioni.size());
			rv.save(volo);
		}

		if (idRitorno != 0) {
			if (rv.findById(idRitorno).getNumPasseggeri() >= listaPrenotazioni.size()) {
				for (Prenotazione p : listaPrenotazioni) {
					rp.save(p);
				}
				Volo volo = rv.findById(idRitorno);
				volo.setNumPasseggeri(volo.getNumPasseggeri() - listaPrenotazioni.size());
				rv.save(volo);
			}
		}

		return "Guest/checkoutEffettuato";
	}
}
