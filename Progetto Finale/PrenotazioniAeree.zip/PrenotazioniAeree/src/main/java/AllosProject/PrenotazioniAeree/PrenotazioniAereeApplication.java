package AllosProject.PrenotazioniAeree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrenotazioniAereeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrenotazioniAereeApplication.class, args);
		System.out.println("Avviato!");
	}

}
