package AllosProject.PrenotazioniAeree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import AllosProject.PrenotazioniAeree.model.Prenotazione;

public interface IRepoPrenotazione extends JpaRepository<Prenotazione, Integer> {
	
	public Prenotazione findById(int id);
	
	@Query(value="Select * from prenotazioni where fk_utente = ?1", nativeQuery=true)
	public List<Prenotazione> findByUtente(int id);
	
	@Query(value="Select * from prenotazioni where nome like %?1% or cognome like %?1%", nativeQuery=true)
	public List<Prenotazione> findByKeyword(String keyword);
}
