package AllosProject.PrenotazioniAeree.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.*;
@Entity
@Table(name="utenti")
public class Utente {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id_utente;
	@NotNull(message="Il nome non può essere null.")
	@Size(min=3, max=30, message = "Il nome prevede 3-30 caratteri.")
	@Column(length=30, nullable=false)
	private String nome;
	@NotNull(message="Il cognome non può essere null.")
	@Size(min=3, max=30, message = "Il cognome prevede 3-30 caratteri.")
	@Column(length=30, nullable=false)
	private String cognome;
	@NotNull(message="La data di nascita non può essere null.")
	@Column(nullable=false)
	private Date dataNascita;
	@NotNull(message="L'email non può essere null.")
	@Email(message="Il pattern della email non è rispettato.")
	@Column(length = 30, nullable = false, unique = true)
	private String email;
	@NotNull(message="La password non può essere null.")
	@Size(min=8, max=30, message = "La password prevede 8-30 caratteri.")
	@Column(length = 30, nullable = false)
	private String password;
	@NotNull(message="La regione non può essere null.")
	@Size(min=3, max=50, message = "La regione prevede 3-50 caratteri.")
	@Column(length=50, nullable=false)
	private String regione;
	@NotNull(message="L'indirizzo non può essere null.")
	@Size(min=3, max=50, message = "L'indirizzo prevede 3-50 caratteri.")
	@Column(length=50, nullable=false)
	private String indirizzo;
	@NotNull(message="La citta non può essere null.")
	@Size(min=3, max=50, message = "La citta prevede 3-50 caratteri.")
	@Column(length=50, nullable=false)
	private String citta;
	@NotNull(message="La provincia non può essere null.")
	@Size(min=3, max=30, message = "La provincia prevede 3-30 caratteri.")
	@Column(length=30, nullable=false)
	private String provincia;
	@NotNull(message="Il cap non può essere null.")
	@Column(length=5, nullable=false)
	private int cap;
	
	@OneToMany(mappedBy = "utente", fetch = FetchType.LAZY)
	private List<Prenotazione> prenotazioni;
	
	public int getId_utente() {
		return id_utente;
	}
	public void setId_utente(int id_utente) {
		this.id_utente = id_utente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public Date getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(Date dataNascita) {
		this.dataNascita = dataNascita;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRegione() {
		return regione;
	}
	public void setRegione(String regione) {
		this.regione = regione;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public String getCitta() {
		return citta;
	}
	public void setCitta(String citta) {
		this.citta = citta;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	public int getCap() {
		return cap;
	}
	public void setCap(int cap) {
		this.cap = cap;
	}
	public List<Prenotazione> getPrenotazioni() {
		return prenotazioni;
	}
	public void setPrenotazioni(List<Prenotazione> prenotazioni) {
		this.prenotazioni = prenotazioni;
	}
	
}
