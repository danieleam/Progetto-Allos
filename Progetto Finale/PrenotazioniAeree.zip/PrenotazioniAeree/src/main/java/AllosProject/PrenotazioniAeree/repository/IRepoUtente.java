package AllosProject.PrenotazioniAeree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import AllosProject.PrenotazioniAeree.model.Utente;

public interface IRepoUtente extends JpaRepository<Utente,Integer>{
	
	public Utente findById(int id);
	
	@Query(value="Select * from utenti where nome like %?1% or cognome like %?1%", nativeQuery=true)
	public List<Utente> findByKeyword(String keyword);
	
}