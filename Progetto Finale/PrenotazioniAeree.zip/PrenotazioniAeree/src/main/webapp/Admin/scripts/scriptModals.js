$(document).ready(function() {
	
	//Modifica Volo
	$('.modalModificaVolo').click(function() {
		var volo = $(this).attr("id");
		var array = volo.split("|");

		$('#id_volo').val(array[0]);
		$('.cittaPartenza').val(array[1]);
		$('.cittaPartenza').html(array[2]);
		$('.cittaArrivo').val(array[3]);
		$('.cittaArrivo').html(array[4]);
		$('.compagnia').val(array[5]);
		$('.compagnia').html(array[6]);
		$('.data').val(array[7]);
		$('.ora').val(array[8]);
		$('#numPasseggeri').val(array[9]);
		$('#prezzo').val(array[10]);
		$('#prezzoScontato').val(array[11]);
	});
	
	$('.modalCancellazioneUtente').click(function(){
		var utente = $(this).attr("id");
		var array = utente.split("|");
		
		$('#linkCancellazione').attr("href", "deleteUtenteAdmin?id="+array[0]);//id utente
		$('#nome').html("Nome: "+array[1]);//nome utente
		$('#cognome').html("Cognome: "+array[2]);//cognome utente
		$('#email').html("Email: "+array[3]);//email utente
	});

	//Modifica Aereoporto
	$('.modalModificaAereoporto').click(function() {
		var aereoporto = $(this).attr("id");
		var array = aereoporto.split("|");

		$('#id_aereoporto').val(array[0]);
		$('.aereoporto').val(array[1]); //utilizzo la classe in quanto il name dell'input è uguale a quello della compagnia, siccome hanno lo stesso attributo nei 2 model
	});

	//Modifica Compagnia
	$('.modalModificaCompagnia').click(function() {
		var compagnia = $(this).attr("id");
		var array = compagnia.split("|");

		$('#id_compagnia').val(array[0]);
		$('.compagnia').val(array[1]); //utilizzo la classe in quanto il name dell'input è uguale a quello dell'aereoporto, siccome hanno lo stesso attributo nei 2 model
	});

	//Eliminazione Volo
	$('.modalCancellazioneVolo').click(function() {
		var volo = $(this).attr("id");
		var array = volo.split("|");

		$('#linkCancellazione').attr("href", "deleteVolo?id=" + array[0]);//id volo
		$('#cittaPartenza').html("Partenza: " + array[1]); //Citta Partenza
		$('#cittaArrivo').html("Arrivo: " + array[2]); //Citta Arrivo
		$('#dataVolo').html("Data volo: " + array[3]); //Data
	});

	//Eliminazione Aereoporto
	$('.aereoporto').click(function() {
		var aereoporto = $(this).attr("id");
		var array = aereoporto.split("|");

		$('#linkCancellazione').attr("href", "deleteAereoporto?id=" + array[0]);//id aereoporto
		$('#aereoportoCompagnia').html("Aereoporto: " + array[1]); //nome aereoporto
	});

	//Eliminazione Compagnia
	$('.compagnia').click(function() {
		var compagnia = $(this).attr("id");
		var array = compagnia.split("|");

		$('#linkCancellazione').attr("href", "deleteCompagnia?id=" + array[0]);//id compagnia
		$('#aereoportoCompagnia').html("Compagnia: " + array[1]); //nome compagnia
	});
});
