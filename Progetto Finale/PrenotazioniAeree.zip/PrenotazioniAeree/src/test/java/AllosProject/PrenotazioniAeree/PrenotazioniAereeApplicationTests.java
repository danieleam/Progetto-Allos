package AllosProject.PrenotazioniAeree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrenotazioniAereeApplicationTests {

	@Test
	void contextLoads() {
	}

}
